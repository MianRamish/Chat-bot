<?php
/*
 * Template Name: Chatbot Template
 * Description: Template for displaying a chatbot.
 */

get_header();
?>

<button id="openChatButton">&#128172;</button>

<div id="usernameModal">
    <div style="text-align: center;">
        <h3>Enter Your Username</h3>
        <input type="text" id="usernameInput" placeholder="Enter your username">
        <button id="submitUsernameButton">Submit</button>
    </div>
</div>

<div id="chatModal">
    <div id="chatHeader">
        <span>Chat with Bellevue Team</span>
        <button id="closeChatButton">&times;</button>
    </div>
    <div id="chatBody" class="chat-box"></div>
    <div id="chatInputContainer">
        <input type="text" id="chatInput" placeholder="Type your message here...">
        <button id="sendMessageButton">Send</button>
    </div>
    <div id="chatFooter">
        <div id="credit">Design and Develop by Bellevue creative</div>
    </div>
</div>

<?php get_footer(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script>
    jQuery(document).ready(function($) {
        var username; // Define username variable globally

        // Open the username modal when the chat icon button is clicked
        $('#openChatButton').click(function() {
            $('#usernameModal').show();
            // Hide the openChatButton when chat modal opens
            $('#openChatButton').hide();
        });

        // Submit the username and open the chat modal when the Submit button is clicked
        $('#submitUsernameButton').click(function() {
            submitUsername();
        });

        // Submit username when Enter key is pressed
        $('#usernameInput').keypress(function(e) {
            if (e.which === 13) {
                submitUsername();
            }
        });

       // Function to submit username
        function submitUsername() {
            username = $('#usernameInput').val().trim(); // Assign value to the global username variable
            if (username === "") {
                alert("Please enter your username.");
                return;
            }
            $('#usernameModal').hide();
            $('#chatBody').empty(); // Clear old chat messages
            $('#chatModal').show();
            // Show the openChatButton when chat modal closes
            $('#openChatButton').hide();
            // Load and display previous messages
            loadMessages(username);
        }


        // Close the chat modal when the user clicks outside of it or on close button
        $('#closeChatButton').click(function() {
            $('#chatModal').hide();
            // Show the openChatButton when chat modal closes
            $('#openChatButton').show();
        });

        $(document).mouseup(function(e) {
            var container = $("#chatModal");
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                container.hide();
                // Show the openChatButton when chat modal closes
                $('#openChatButton').show();
            }
        });

        // Send message when the Send button is clicked
        $('#sendMessageButton').click(function() {
            sendMessage();
        });

        // Send message when Enter key is pressed
        $('#chatInput').keypress(function(e) {
            if (e.which === 13) {
                sendMessage();
            }
        });

        // Function to display typing indicator
        function showTypingIndicator() {
            var typingIndicator = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
            $('#chatBody').append(typingIndicator);
        }

        // Function to hide typing indicator
        function hideTypingIndicator() {
            $('.typing-indicator').remove();
        }

        // Function to send message
        function sendMessage() {
            var userInput = $('#chatInput').val();
            if (userInput.trim() === "") {
                return;
            }
            
            var userMessage = '<div class="chat-message user-message"><span class="username">You:</span><span class="message">' + userInput + '</span></div>';
            $('#chatBody').append(userMessage);
            $('#chatInput').val("");

            // Show typing indicator
            showTypingIndicator();

            // Save user message in local storage
            saveMessage(username, userInput, true);
            
            // Handle bot response or API call after a short delay to simulate typing
            setTimeout(function() {
                handleBotResponse(userInput);
            }, 1000);
        }

        // Function to save message in local storage
        function saveMessage(username, message, isUserMessage) {
            var chatHistory = JSON.parse(localStorage.getItem('chatHistory')) || {};
            if (!chatHistory[username]) {
                chatHistory[username] = [];
            }
            chatHistory[username].push({
                message: message,
                isUserMessage: isUserMessage
            });
            localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
        }

        // Function to load and display previous messages
        function loadMessages(username) {
            var chatHistory = JSON.parse(localStorage.getItem('chatHistory')) || {};
            if (chatHistory[username]) {
                chatHistory[username].forEach(function(data) {
                    if (data.isUserMessage) {
                        var userMessage = '<div class="chat-message user-message"><span class="username">' + username + ':</span><span class="message">' + data.message + '</span></div>';
                        $('#chatBody').append(userMessage);
                    } else {
                        var botMessage = '<div class="chat-message bot-message"><span class="username">Bellevue Team:</span><span class="message">' + data.message + '</span></div>';
                        $('#chatBody').append(botMessage);
                    }
                });
            }
        }

        // Function to handle bot response or API call
        function handleBotResponse(userInput) {
            // Example: Bot response based on user input
            var customResponse = getCustomResponse(userInput);
            if (customResponse) {
                displayBotResponse(customResponse);
                // Save bot response in local storage
                saveMessage(username, customResponse, false);
            } else {
                // Example: Call an API for bot response
                callBotAPI(userInput);
            }
        }

        // Example: Custom responses based on user input
        function getCustomResponse(input) {
            if (input.toLowerCase().includes("hello")) {
                return "Hello! How can Team Bellevue assist you today?";
            } else if (input.toLowerCase().includes("need help")) {
                return "Sure, I'm here to help! What do you need assistance with?";
            }
            // Add more custom responses as needed
            return null; // Return null if no custom response matches
        }

        // Example: Display bot response
        function displayBotResponse(response) {
            var botMessage = '<div class="chat-message bot-message"><span class="username">Bellevue Team:</span><span class="message">' + response + '</span></div>';
            // Remove typing indicator before displaying bot message
            hideTypingIndicator();
            $('#chatBody').append(botMessage);
        }

        // Example: Call an API for bot response
        function callBotAPI(userInput) {
            var settings = {
                "url": "https://api.writesonic.com/v2/business/content/chatsonic",
                "method": "POST",
                "timeout": 0,
                "headers": {
                    "Content-Type": "application/json",
                    "X-API-KEY": "d8c0d3da-b323-4ad9-bdd2-fdcb9c4c3d61"
                },
                "data": JSON.stringify({
                    "input_text": userInput,
                    "enable_google_results": "true",
                    "enable_memory": false
                }),
            };

            $.ajax(settings)
            .done(function(response) {
                if (response && response.message) {
                    var truncatedMessage = response.message.length > 200 ? response.message.substring(0, 200) + "..." : response.message;
                    displayBotResponse(truncatedMessage);
                    // Save bot response in local storage
                    saveMessage(username, truncatedMessage, false);
                } else {
                    console.error("Response is missing message property:", response);
                }
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
                console.error("AJAX request failed:", textStatus, errorThrown);
            });
        }
    });
</script>

<?php 
get_footer();
?>
